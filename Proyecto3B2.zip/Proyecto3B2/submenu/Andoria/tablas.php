<!DOCTYPE html>

<html lang="es">

<head> 

 <title> Visualizar Inventario </title>
 <meta charset="UTF-8">
 <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1, maximum-scale=1, minimum-scale=1">
 <link rel="stylesheet" href="css/fontello.css">
 <link rel="stylesheet" href="css/estilos.css">
 <style>
    @media only screen and (max-width: 500px) {
        body {
            background-color: rgb(214, 0, 0);
            color: rgb(0, 0, 0);
        }
    }

    table {
            border-spacing: 10px;
            border-collapse: collapse;
            align-self: center;
            background-color: rgb(214, 0, 0);
            font-size: 20px;
            color: #ffffff;
        }
       th tr td thead {
            padding:15px 15px 15px 15px;
            border:1px solid rgb(214, 0, 0);
            color: #ffffff;
        }

  </style>
 </head>
 <link rel="shortcut icon" href="../Andoria/img/bbb.png" type="image/x-icon">

    <body>
        <header>
            <div class="contenedor">
                <h1 >Visualizar Inventario</h1>
                <input type="checkbox" id="menu-bar">
                    <label class="icon-menu" for="menu-bar"></label>
                    <nav class="menu">
                        <a href="../../index.html"> Home </a>
                        <a href="tablas.php"> Tablas </a>
                        <a href="../../submenu4/Andoria/index.html"> Ir a factura </a>
                        <a href="../../submenu2/Andoria/index.html"> Gestionar Productos </a>
                    </nav>
            </div>
        </header>

        <main>
            <section id="banner">
                <img src="img/banner.jpg">
                <div class="contenedor">
                <h2>Text</h2>
                <p>Text</p>
                <a href="https://youtube.com/playlist?list=PLE_WwtGjBCYfd_h7eZBvZ_ZTw2mZ3JHut">Click</a>
            </div>
            </section>

            <section id="bienvenidos">
                <h2>PRODUCTOS 3B</h2><br>
                <p>¡Productos de calidad BBB!<br>
                </p> 
            </section>

            <section id="blog">
                <h3>Inventario</h3><br><br>
                <div class="contenedor">
                <?php 

	        $conexion=mysqli_connect('localhost','root','','tiendasbbb');

        ?>
	<table border="1" >
		<tr>
			<td>Nombre Del Producto</td>
			<td>Clave Del Producto</td>
			<td>Departamento</td>
			<td>Precio</td>
			<td>Cantidad</td>
			<td>Marca</td>
            <td>Descripción</td>
		</tr>

		<?php 
		$sql="SELECT * from productos";

		$result=mysqli_query($conexion,$sql);

		while($mostrar=mysqli_fetch_array($result)){
		 ?>

		<tr>
			<td><?php echo $mostrar['Clave'] ?></td>
			<td><?php echo $mostrar['NombreDelProducto'] ?></td>
			<td><?php echo $mostrar['Departamento'] ?></td>
			<td><?php echo $mostrar['Precio'] ?></td>
			<td><?php echo $mostrar['Inventario'] ?></td>
			<td><?php echo $mostrar['Marca'] ?></td>
            <td><?php echo $mostrar['Descripcion'] ?></td>
		</tr>
	<?php 
	}
	 ?>
	</table>    

                </div>
            </section>

        </main>

<footer>
    <div class="contenedor">
        <p class="copy">Tiendas 3B &copy; 2022</p>
        <div class="sociales">
            <a class="icon-facebook" href="https://www.facebook.com/andrea.coss.5680"></a>
            <a class="icon-instagram" href="https://www.instagram.com/andoria_coss/"></a>
            <a class="icon-twitter" href="https://twitter.com/SeoritaMiel2"></a>
        </div>
    </div>
</footer>

    </body>

</html>

