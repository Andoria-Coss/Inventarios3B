-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 22-05-2022 a las 06:46:40
-- Versión del servidor: 5.6.21
-- Versión de PHP: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `tiendasbbb`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `contactos`
--

CREATE TABLE IF NOT EXISTS `contactos` (
  `nombre` varchar(40) NOT NULL,
  `direccion` varchar(40) NOT NULL,
  `telefono` varchar(40) NOT NULL,
  `email` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `contactos`
--

INSERT INTO `contactos` (`nombre`, `direccion`, `telefono`, `email`) VALUES
('Diana Prince', 'Orizaba', '2711544556', 'tareaspquitl@gmail.com'),
('Ricardo Jr', 'Tapia Fernadez', '2781896790', 'tareaspquitl@gmail.com'),
('Jon Bon', 'Jovi', '12345000', 'tareaspquitl@gmail.com'),
('Fredy Mercury', 'LONDON', '345678912', 'tareaspquitl@gmail.com'),
('', 'Mendoza', '0997712345', 'tareaspquitl@gmail.com'),
('Petra Perez GRACIA', 'Orizaba, VER', '6789234678', 'tareaspquitl@gmail.com');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empleados`
--

CREATE TABLE IF NOT EXISTS `empleados` (
  `CEmpleados` varchar(25) NOT NULL DEFAULT 'not null',
  `Nombre` varchar(25) NOT NULL DEFAULT 'not null',
  `ApellidoPaterno` varchar(25) NOT NULL DEFAULT 'not null',
  `ApellidoMaterno` varchar(25) NOT NULL DEFAULT 'not null',
  `Direccion` varchar(100) NOT NULL DEFAULT 'not null',
  `Telefono` varchar(10) NOT NULL DEFAULT 'not null',
  `Correo` varchar(100) NOT NULL DEFAULT 'not null'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `empleados`
--

INSERT INTO `empleados` (`CEmpleados`, `Nombre`, `ApellidoPaterno`, `ApellidoMaterno`, `Direccion`, `Telefono`, `Correo`) VALUES
('AC2501', 'ANDREA', 'COSS', 'ESPINOSA', 'FRANCISCO I MADERO #2 ENCINAR NOGALES VER', '2721732621', 'andreacoss123@gmail.com');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE IF NOT EXISTS `productos` (
  `Clave` varchar(10) NOT NULL,
  `NombreDelProducto` varchar(25) NOT NULL,
  `Departamento` varchar(25) NOT NULL,
  `Precio` float NOT NULL,
  `Inventario` int(11) NOT NULL,
  `Marca` varchar(45) NOT NULL,
  `Descripcion` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`Clave`, `NombreDelProducto`, `Departamento`, `Precio`, `Inventario`, `Marca`, `Descripcion`) VALUES
('cf123', 'Salchicha Viena', 'Carnes Frías', 70, 100, 'Sparta', '1 Kg'),
('cf234', 'Jamón de Pavo', 'Carnes Frías', 27, 100, 'Sparta', '250 g'),
('cf345', 'JamÃ³n de Pavo', 'Carnes FrÃ­as', 97, 100, 'Sparta', '1 Kg'),
('du345', 'Chocolate Oscuro', 'Dulces', 25, 100, 'Lancelot', '70 g');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `empleados`
--
ALTER TABLE `empleados`
 ADD PRIMARY KEY (`CEmpleados`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
 ADD PRIMARY KEY (`Clave`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
