<?php

$conexion=mysqli_connect('localhost','root','','tiendasbbb');


$NombreDelProducto=$_POST['nombre'];
$Clave=$_POST['id'];
$Departamento=$_POST['dep'];
$Precio=$_POST['precio'];
$Inventario=$_POST['cantidad'];
$Marca=$_POST['marca'];
$Descripcion=$_POST['descripcion'];


$sql="UPDATE productos SET Clave='$Clave', NombreDelProducto='$NombreDelProducto', Departamento='$Departamento', Precio='$Precio', Inventario='$Inventario', Marca='$Marca', Descripcion='$Descripcion' WHERE Clave='$Clave'";

$result=mysqli_query($conexion,$sql);

if($result)
{ 
         echo "Datos enviados correctamente";
}   
else{
    echo "Error al enviar datos";
}
?>