<?php

$conexion=mysqli_connect('localhost','root','','tiendasbbb');



$Clave=$_GET['id'];


$sql="DELETE FROM productos  WHERE Clave='$Clave'";

$result=mysqli_query($conexion,$sql);

if($result)
{ 
         echo "Datos borrados correctamente";
}   
else{
    echo "Error al borrar datos";
}
?>